# @nexusai360/core

Fundação do Nexus Blueprint: Auth, Users, Rate Limit, Email, Permissions e builders de Password Reset / Email Change. Zero dependência direta de Prisma — o consumidor pluga seu próprio schema via adapters.

## Instalação

```bash
pnpm add @nexusai360/core @nexusai360/types bcryptjs ioredis resend @react-email/components react
```

## Bootstrap

```typescript
import Redis from "ioredis";
import { configureRateLimit } from "@nexusai360/core/rate-limit";
import { configureEmail } from "@nexusai360/core/email";
import {
  configureUsers,
  configurePasswordResetTokens,
  configureEmailChangeTokens,
} from "@nexusai360/core/users";
import { prisma } from "@/lib/prisma";

configureRateLimit(new Redis(process.env.REDIS_URL!));
configureEmail(process.env.RESEND_API_KEY!, "no-reply@exemplo.com", "Minha App");

configureUsers({
  findByEmail: (email) => prisma.user.findFirst({ where: { email, deletedAt: null } }),
  findById: (id) => prisma.user.findFirst({ where: { id, deletedAt: null } }),
  create: (data) => prisma.user.create({ data }),
  update: (id, data) => prisma.user.update({ where: { id }, data }),
});

configurePasswordResetTokens({
  create: (data) => prisma.passwordResetToken.create({ data }),
  findByToken: (token) => prisma.passwordResetToken.findUnique({ where: { token } }),
  markUsed: async (id) => {
    await prisma.passwordResetToken.update({ where: { id }, data: { usedAt: new Date() } });
  },
  findLatestByUser: (userId) =>
    prisma.passwordResetToken.findFirst({
      where: { userId },
      orderBy: { createdAt: "desc" },
    }),
});

configureEmailChangeTokens({
  create: (data) => prisma.emailChangeToken.create({ data }),
  findByToken: (token) => prisma.emailChangeToken.findUnique({ where: { token } }),
  markUsed: async (id) => {
    await prisma.emailChangeToken.update({ where: { id }, data: { usedAt: new Date() } });
  },
  findLatestByUser: (userId) =>
    prisma.emailChangeToken.findFirst({
      where: { userId },
      orderBy: { createdAt: "desc" },
    }),
});
```

## Subsistemas

### `@nexusai360/core/auth`

```typescript
import { hashPassword, validatePassword, validatePasswordStrength } from "@nexusai360/core/auth";

const hash = await hashPassword("s3nha!forte");
const ok = await validatePassword("s3nha!forte", hash);
const { valid, errors } = validatePasswordStrength("s3nha!forte", { minLength: 8, requireNumber: true });
```

### `@nexusai360/core/rate-limit`

```typescript
import { checkRateLimit, recordAttempt, applyProgressiveLockout, DEFAULT_LOCKOUT_TIERS } from "@nexusai360/core/rate-limit";

const rl = await checkRateLimit("login:ip:1.2.3.4", Infinity, 60_000);
if (!rl.allowed) return { retryAfter: rl.retryAfter };

const attempts = await recordAttempt("login:ip:1.2.3.4", 60_000);
await applyProgressiveLockout("login:ip:1.2.3.4", attempts);
```

Tiers padrão: 5 tentativas → 15min, 10 → 1h, 20 → 24h.

### `@nexusai360/core/email`

```typescript
import { sendEmail, PasswordResetEmail } from "@nexusai360/core/email";
import { createElement } from "react";

await sendEmail({
  to: "user@exemplo.com",
  subject: "Redefina sua senha",
  react: createElement(PasswordResetEmail, {
    userName: "João",
    resetUrl: "https://app.exemplo.com/reset-password?token=...",
  }),
});
```

### `@nexusai360/core/permissions`

```typescript
import { hasPlatformPermission, assertPlatformPermission, getRoleLabel } from "@nexusai360/core/permissions";

if (!hasPlatformPermission(user.platformRole, "admin")) return { error: "forbidden" };
assertPlatformPermission(user.platformRole, "admin"); // lança AuthError se não
```

### `@nexusai360/core/users` — builders

```typescript
import {
  authenticateUser,
  requestPasswordReset,
  resetPassword,
  requestEmailChange,
  confirmEmailChange,
} from "@nexusai360/core/users-builders";
import { PasswordResetEmail, sendEmail } from "@nexusai360/core/email";
import { createElement } from "react";

// login
const result = await authenticateUser(email, password, { ipAddress });
if (!result.user) return { error: result.error };

// reset (solicitação — anti-enumeration)
await requestPasswordReset(email, {
  baseUrl: "https://app.exemplo.com",
  onTokenCreated: async ({ user, resetUrl }) => {
    await sendEmail({
      to: user.email,
      subject: "Redefina sua senha",
      react: createElement(PasswordResetEmail, { userName: user.name, resetUrl }),
    });
  },
});

// reset (confirmação)
const res = await resetPassword(token, newPassword, {
  transaction: (fn) => prisma.$transaction(async () => { await fn(); }),
});
```

## Schema Prisma

O template completo vive em `src/core.prisma.template` (também exposto via `@nexusai360/core/prisma-template`). Copie os blocos para o seu `schema.prisma` e rode `prisma generate`. O adapter é responsável por filtrar `deletedAt: null` em `findByEmail`/`findById`.

## Referência completa

Veja `docs/superpowers/specs/2026-04-14-core-package-design.md` no monorepo `nexus-blueprint`.
