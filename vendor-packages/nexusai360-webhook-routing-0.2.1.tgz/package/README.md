# @nexusai360/webhook-routing

Pipeline generico de webhooks para o Nexus Blueprint: receber, verificar HMAC, normalizar, deduplicar e rotear. Sem Prisma — voce injeta o adapter.

## Instalacao

```bash
pnpm add @nexusai360/webhook-routing @nexusai360/multi-tenant nanoid
```

## Uso

```ts
import {
  configureWebhookRouting,
  registerWebhookRoute,
  receiveWebhook,
  validateDestinationUrl,
  verifyHmacSignature,
} from "@nexusai360/webhook-routing";
import { createPrismaWebhookAdapter } from "@/lib/webhooks/adapter";

configureWebhookRouting(createPrismaWebhookAdapter());

await registerWebhookRoute({
  companyId,
  name: "Analytics",
  url: "https://analytics.example.com/ingest",
  events: ["messages.text", "statuses.delivered"],
});

const result = await receiveWebhook({
  companyId,
  rawBody,
  signatureHeader: req.headers["x-hub-signature-256"],
  secret: appSecret,
  events: normalizedEvents,
});
```

## Helpers puros

- `verifyHmacSignature` — HMAC-SHA256 timing-safe
- `buildDedupeKey` — chave SHA256 versionada (v1)
- `validateDestinationUrl` — SSRF guard (HTTPS, bloqueia IPs privados/loopback)
- `matchRoutes` — filtra rotas ativas por `eventType`
- `normalizePayload` — generico, aceita extractor custom

## Erros

- `webhook_routing_not_configured`
- `invalid_signature`
- `invalid_destination_url:<reason>`
- `route_not_found` / `route_name_already_exists` / `route_url_already_exists`
