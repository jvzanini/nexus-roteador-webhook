# @nexusai360/multi-tenant

Módulo multi-tenant do Nexus Blueprint — Companies, memberships, tenant scoping, roles e geração de slug. Pacote TS puro, server-safe, sem dependência de React ou Prisma client.

## Instalação

```bash
pnpm add @nexusai360/multi-tenant @nexusai360/core @nexusai360/types nanoid
```

## Exports

| Subpath | Conteúdo |
|---------|----------|
| `@nexusai360/multi-tenant` | Barrel com tudo. |
| `@nexusai360/multi-tenant/roles` | `CompanyRole`, `COMPANY_ROLE_HIERARCHY`, `COMPANY_ROLE_LABELS`, `COMPANY_ROLE_OPTIONS`, `hasCompanyPermission`. |
| `@nexusai360/multi-tenant/tenant-scoping` | `buildTenantFilter`, `resolveTenantFilter`, `getAccessibleCompanyIds`, `assertCompanyAccess`, `getUserCompanyRole`, `getUserCompanyRoleForUser`, `hasFeature`. |
| `@nexusai360/multi-tenant/builders` | `configureCompanies`, `getCompanies`, `getCompanyById`, `createCompany`, `updateCompany`, `deleteCompany`, `updateCompanyFeatures`, `addMembership`, `updateMembership`, `removeMembership`. |
| `@nexusai360/multi-tenant/prisma-template` | Path para o arquivo `multi-tenant.prisma.template` (raw). |

## Padrão adapter + singleton

O pacote segue o mesmo padrão do `@nexusai360/core/users`: o consumidor implementa um `CompanyAdapter` (Prisma, Drizzle, in-memory, etc.) e injeta via `configureCompanies(adapter)`. Os builders puros consomem o adapter configurado.

```typescript
import { configureCompanies, type CompanyAdapter } from "@nexusai360/multi-tenant";

const adapter: CompanyAdapter = {
  findById: (id) => prisma.company.findUnique({ where: { id } }),
  findBySlug: (slug) => prisma.company.findUnique({ where: { slug } }),
  list: ({ ids, includeInactive }) =>
    prisma.company.findMany({
      where: {
        ...(ids ? { id: { in: ids } } : {}),
        ...(includeInactive ? {} : { isActive: true }),
      },
    }),
  create: (data) => prisma.company.create({ data }),
  update: (id, data) => prisma.company.update({ where: { id }, data }),
  delete: async (id) => {
    await prisma.$transaction([
      prisma.notification.deleteMany({ where: { companyId: id } }),
      prisma.auditLog.deleteMany({ where: { companyId: id } }),
      prisma.userCompanyMembership.deleteMany({ where: { companyId: id } }),
      prisma.company.delete({ where: { id } }),
    ]);
  },
  listMembershipsByUser: (userId) =>
    prisma.userCompanyMembership.findMany({ where: { userId } }),
  listMembershipsByCompany: (companyId) =>
    prisma.userCompanyMembership.findMany({ where: { companyId } }),
  findMembership: (userId, companyId) =>
    prisma.userCompanyMembership.findUnique({ where: { userId_companyId: { userId, companyId } } }),
  createMembership: (data) => prisma.userCompanyMembership.create({ data }),
  updateMembership: (id, data) => prisma.userCompanyMembership.update({ where: { id }, data }),
  deleteMembership: async (id) => {
    await prisma.userCompanyMembership.delete({ where: { id } });
  },
};

configureCompanies(adapter);
```

## Uso — Tenant scoping

```typescript
import {
  resolveTenantFilter,
  assertCompanyAccess,
  getUserCompanyRoleForUser,
} from "@nexusai360/multi-tenant/tenant-scoping";

// Em Server Action:
const filter = await resolveTenantFilter(currentUser);
const logs = await prisma.inboundWebhook.findMany({ where: { ...filter, ...otherFilters } });

// Em CRUD de rota:
const memberships = await adapter.listMembershipsByUser(currentUser.id);
assertCompanyAccess(currentUser, companyId, memberships);

// Para UI (definir o que mostrar):
const role = getUserCompanyRoleForUser(currentUser, companyId, memberships);
```

## Uso — Roles

```typescript
import {
  COMPANY_ROLE_OPTIONS,
  hasCompanyPermission,
} from "@nexusai360/multi-tenant/roles";

if (!hasCompanyPermission(role, "company_admin")) {
  throw new Error("forbidden");
}
```

`super_admin` **nunca** é persistido em `UserCompanyMembership` — é injetado em runtime por `getUserCompanyRoleForUser` quando o usuário é plataforma super admin. Os builders `addMembership`/`updateMembership` rejeitam `role: "super_admin"`.

## Uso — Company CRUD

```typescript
import {
  createCompany,
  updateCompany,
  updateCompanyFeatures,
} from "@nexusai360/multi-tenant/builders";

// slug derivado do nome com unicidade via adapter:
const c = await createCompany({ name: "Acme Inc.", features: { billing: true } });

// regenera slug automaticamente se o nome mudar:
await updateCompany(c.id, { name: "Acme Corp", regenerateSlugFromName: true });

// feature flags (substitui o objeto inteiro):
await updateCompanyFeatures(c.id, { billing: true, apiKeys: false });
```

## Schema Prisma

Use o template fornecido em `src/multi-tenant.prisma.template`:

```bash
cat node_modules/@nexusai360/multi-tenant/src/multi-tenant.prisma.template >> prisma/schema.prisma
```

Campos opcionais por pattern (ex.: `webhookKey` do `webhook-routing`) devem ser adicionados sob demanda — veja `modules/multi-tenant.md` no repositório `nexus-blueprint`.

## Fora do escopo

- Componentes UI (lista, cards, dialogs) — ficam em `@nexusai360/multi-tenant-ui` (futuro) ou no app consumidor.
- Validações com Zod — responsabilidade do caller.
- Cascade delete — o adapter decide como implementar (transaction + ordem dependente).
- Feature flag externo (LaunchDarkly, Flagsmith) — suportamos apenas o campo `features` JSON embutido.
